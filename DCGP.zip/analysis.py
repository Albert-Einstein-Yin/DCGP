# plt.show()
import numpy as np
from matplotlib import cm
import matplotlib.colors as col
from mpl_toolkits.mplot3d import Axes3D
import matplotlib.pyplot as plt
from matplotlib.ticker import MultipleLocator
from pylab import xticks,yticks,np
# Data generation
alpha = np.linspace(0, 5, 16)

# print(alpha)
beta = [0.001,0.01,0.1,1,10]
beta = np.array(beta)
print(beta)

a_grid, b_grid = np.meshgrid(alpha, beta)
data = [[1,2,3,4,5,6,7,8,9,1,2,3,4,5,6,7],
        [1,2,3,4,5,6,7,8,9,1,2,3,4,5,6,7],
        [1,2,3,4,5,6,7,8,9,1,2,3,4,5,6,7],
        [1,2,3,4,5,6,7,8,9,1,2,3,4,5,6,7],
        [1,2,3,4,5,6,7,8,9,1,2,3,4,5,6,7],]
data = np.array(data)
print(data)
# Plotting
fig = plt.figure()
ax = fig.add_subplot(projection='3d')

xi = a_grid.flatten()
yi = b_grid.flatten()
zi = np.zeros(data.size)
dx = .30 * np.ones(data.size)
dy = .30 * np.ones(data.size)
dz = data.flatten()
ax.set_xlabel(r'$\alpha$')
ax.set_ylabel(r'$\beta$')
ax.set_zlabel('ACC')
colors = plt.cm.jet(data.flatten()/float(data.max()))
ax.bar3d(xi, yi, zi, dx, dy, dz, color=colors)

plt.show()
plt.savefig('311')
