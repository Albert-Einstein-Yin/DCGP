from sklearn.metrics import v_measure_score, adjusted_rand_score, accuracy_score
from sklearn.cluster import KMeans
from scipy.optimize import linear_sum_assignment
from torch.utils.data import DataLoader
import numpy as np
import torch
import os
from sklearn.manifold import TSNE
import matplotlib.pyplot as plt
import warnings
warnings.filterwarnings("ignore", category=FutureWarning, module="sklearn", lineno=783)
warnings.filterwarnings("ignore", category=FutureWarning, module="sklearn", lineno=793)



def cluster_acc(y_true, y_pred):
    y_true = y_true.astype(np.int64)
    assert y_pred.size == y_true.size
    D = max(y_pred.max(), y_true.max()) + 1
    w = np.zeros((D, D), dtype=np.int64)
    # y_pred = y_pred.astype(int)
    # y_true = y_true.astype(int)
    for i in range(y_pred.size):
        w[y_pred[i], y_true[i]] += 1
    u = linear_sum_assignment(w.max() - w)
    ind = np.concatenate([u[0].reshape(u[0].shape[0], 1), u[1].reshape([u[0].shape[0], 1])], axis=1)
    return sum([w[i, j] for i, j in ind]) * 1.0 / y_pred.size

def purity(y_true, y_pred):
    y_voted_labels = np.zeros(y_true.shape)
    labels = np.unique(y_true)
    ordered_labels = np.arange(labels.shape[0])
    for k in range(labels.shape[0]):
        y_true[y_true == labels[k]] = ordered_labels[k]
    labels = np.unique(y_true)
    bins = np.concatenate((labels, [np.max(labels)+1]), axis=0)

    for cluster in np.unique(y_pred):
        hist, _ = np.histogram(y_true[y_pred == cluster], bins=bins)
        winner = np.argmax(hist)
        y_voted_labels[y_pred == cluster] = winner

    return accuracy_score(y_true, y_voted_labels)

def evaluate(label, pred):
    nmi = v_measure_score(label, pred)
    ari = adjusted_rand_score(label, pred)
    acc = cluster_acc(label, pred)
    pur = purity(label, pred)
    return acc, nmi, pur, ari

def inference(loader, model, device, view, data_size):
    model.eval()
    commonZ = []
    commonQ = []
    labels_vector = []
    for step, (xs, y, _) in enumerate(loader):
        for v in range(view):
            xs[v] = xs[v].to(device)
        with torch.no_grad():
            commonz, _,commonq = model.GCFAgg(xs)
            commonz = commonz.detach()
            commonZ.extend(commonz.cpu().detach().numpy())
            commonQ.extend(commonq.cpu().detach().numpy())
        labels_vector.extend(y.numpy())
    labels_vector = np.array(labels_vector).reshape(data_size)
    total_pred = np.argmax(np.array(commonQ), axis=1)
    commonZ = np.array(commonZ)
   
    
    return commonQ,labels_vector, commonZ,total_pred


def valid(model, device, dataset, view, data_size, class_num,dataname,batch_size,alpha,beta,lr):
    test_loader = DataLoader(
            dataset,
            batch_size=256,
            shuffle=False,
        )
    commonq,labels_vector, commonZ,total_pred = inference(test_loader, model, device, view, data_size)
    kmeans = KMeans(n_clusters=class_num, n_init=100)
    y_pred = kmeans.fit_predict(commonZ)
    
    acc, nmi, pur, ari = evaluate(labels_vector, y_pred)
    
 
    
    print('---------train over---------')
    print("Clustering results on Golbal features:")

    print('ACC = {:.4f} NMI = {:.4f} PUR={:.4f} ARI = {:.4f}'.format(acc, nmi, pur, ari))
    if not os.path.exists('./res'):
        os.makedirs('./res')
    with open('My-main/res/result_%s.txt' % dataname, 'a+') as f:
        f.write('batch_size =  {}\t {:.4f} \t {:.4f} \t {:.4f} \t {:.4f} a = {:.2f} b = {:.2f} lr = {} feature\n'
                .format(batch_size,acc, nmi, pur, ari,alpha,beta,lr))
        f.flush() 
    
    