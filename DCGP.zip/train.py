import torch
from network import GCFAggMVC
from metric import valid,inference
from torch.utils.data import Dataset
import numpy as np
import argparse
import random
from loss import Loss 
from dataloader import load_data
import os
import time
from sklearn.preprocessing import MinMaxScaler
from sklearn.cluster import KMeans
from scipy.optimize import linear_sum_assignment
import torch.nn.functional as F
# os.environ["CUDA_VISIBLE_DEVICES"] = "0"
# Synthetic3d
# Prokaryotic
# BDGP
# Fashion
# MNIST-USPS
# Hdigit
# Cora

Dataname = 'Prokaryotic'
parser = argparse.ArgumentParser(description='train')
parser.add_argument('--dataset', default=Dataname)
parser.add_argument('--batch_size', default=256, type=int)
parser.add_argument("--temperature_f", default=0.5)
parser.add_argument("--temperature_l", default=1.0)
parser.add_argument("--learning_rate", default=0.0001)
parser.add_argument("--weight_decay", default=0.)
parser.add_argument("--workers", default=8)
parser.add_argument("--alp",default=0.1)
parser.add_argument("--beta",default=0.15)

# parser.add_argument("--gama",default=0.1)
parser.add_argument("--rec_epochs", default=200)
parser.add_argument("--fine_tune_epochs", default=100)
parser.add_argument("--low_feature_dim", default=512)
parser.add_argument("--high_feature_dim", default=128)
args = parser.parse_args()
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")


if args.dataset == "Prokaryotic": 
    args.fine_tune_epochs = 68
    args.learning_rate = 0.0003
    args.alp = 0.15
    seed = 10

    
print("==========\nArgs:{}\n==========".format(args))
    
def setup_seed(seed):
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    np.random.seed(seed)
    random.seed(seed)
    torch.backends.cudnn.deterministic = True
    # torch.backends.cudnn.benchmark = False

setup_seed(seed)

dataset, dims, view, data_size, class_num = load_data(args.dataset)


data_loader = torch.utils.data.DataLoader(
        dataset,
        batch_size=args.batch_size,
        shuffle=True,
        drop_last=True,
    )

def pre_train(epoch):
    tot_loss = 0.
    mse = torch.nn.MSELoss()
    for batch_idx, (xs, _, _) in enumerate(data_loader):
        for v in range(view):
            xs[v] = xs[v].to(device)
        optimizer.zero_grad()
        xrs, zs, _, _ = model(xs)
        loss_list = []
        for v in range(view):
            # Reconstruction loss
            loss_list.append(mse(xs[v], xrs[v]))
        loss = sum(loss_list)
        loss.backward()
        optimizer.step()
        tot_loss += loss.item()
    if epoch % 10 == 0 :
        print('Pre-training: Epoch {}'.format(epoch), 'Loss:{:.6f}'.format(tot_loss / len(data_loader)))
    
def fine_tune(epoch):
    tot_loss = 0.
    mse = torch.nn.MSELoss()
    for batch_idx, (xs, _, _) in enumerate(data_loader):
        for v in range(view):
            xs[v] = xs[v].to(device)
        optimizer.zero_grad()
        xrs, zs, hs ,qs= model(xs)
        commonz, S,commonq = model.GCFAgg(xs)
        loss_list = []
        for v in range(view):
            loss_list.append(criterion.Structure_guided_Contrastive_Loss(hs[v], commonz, S))
            loss_list.append(mse(xs[v], xrs[v]))
            loss_list.append(args.beta*criterion.Label_Contrastive_Loss(qs[v],commonq))
            for i in range(args.batch_size):
                for j in range(i+1,args.batch_size):
                    if torch.argmax(commonq[i])==torch.argmax(commonq[j]):
                        S[i][j]=1
            
            for w in range(v+1,view):
                loss_list.append(args.alp * mse(zs[v] , zs[w]))
                
        loss = sum(loss_list)
        loss.backward()
        optimizer.step()
        tot_loss += loss.item()
    print('Fine-tune: Epoch {}'.format(epoch), 'Loss:{:.6f}'.format(tot_loss/len(data_loader)))

def target_distribution(q):
    weight = q ** 2 / q.sum(0)
    return (weight.t() / weight.sum(1)).t()

# if not os.path.exists('./models'):
#     os.makedirs('./models')


t = time.perf_counter()
model = GCFAggMVC(view, dims, args.low_feature_dim, args.high_feature_dim, class_num,False,device)
# print(model)
model = model.to(device)
optimizer = torch.optim.Adam(model.parameters(), lr=args.learning_rate, weight_decay=args.weight_decay)
criterion = Loss(args.batch_size, args.temperature_f, args.temperature_l, class_num,device).to(device)

epoch = 1
t1 = time.time()
while epoch <= args.rec_epochs:
    pre_train(epoch)
    epoch += 1
print("Pre-training finished.")
print("Time elapsed: {:.4f}s".format(time.time() - t1))
while epoch <= args.rec_epochs + args.fine_tune_epochs :
    fine_tune(epoch)
    if epoch == args.rec_epochs + args.fine_tune_epochs:
        valid(model, device, dataset, view, data_size, class_num,Dataname,args.batch_size,args.alp,args.beta,args.learning_rate)
        # state = model.state_dict()
        # torch.save(state, './models/' + args.dataset + '.pth')
        # print('Saving model...')
    # if epoch %10==0:
    #     print(f'coast:{time.perf_counter() - t:.8f}s')
    epoch += 1
# print(f'Total coast:{time.perf_counter() - t:.8f}s')