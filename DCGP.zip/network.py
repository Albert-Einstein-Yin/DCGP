from torch import nn
from torch.nn.functional import normalize
import torch
import numpy as np
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
import numpy as np
from itertools import chain

class Encoder(nn.Module):
    def __init__(self, input_dim, feature_dim):
        super(Encoder, self).__init__()
        self.encoder = nn.Sequential(
            nn.Linear(input_dim, 500),
            nn.ReLU(),
            nn.Linear(500, 500),
            nn.ReLU(),
            nn.Linear(500, 2000),
            nn.ReLU(),
            nn.Linear(2000, feature_dim),
        )
    def forward(self, x):
        return self.encoder(x)
    
class Decoder(nn.Module):
    def __init__(self, input_dim, feature_dim):
        super(Decoder, self).__init__()
        self.decoder = nn.Sequential(
            nn.Linear(feature_dim, 2000),
            nn.ReLU(),
            nn.Linear(2000, 500),
            nn.ReLU(),
            nn.Linear(500, 500),
            nn.ReLU(),
            nn.Linear(500, input_dim),
        )
    def forward(self, x):
        return self.decoder(x)

  
class GCFAggMVC(nn.Module):
    def __init__(self, view,input_size,low_feature_dim, high_feature_dim,class_num, flag ,device):
        super(GCFAggMVC, self).__init__()
        self.encoders = []
        self.decoders = []
        for v in range(view):
            self.encoders.append(Encoder(input_size[v], low_feature_dim).to(device))
            self.decoders.append(Decoder(input_size[v], low_feature_dim).to(device))
            
        self.encoders = nn.ModuleList(self.encoders)
        self.decoders = nn.ModuleList(self.decoders)
        

        self.Specific_view = nn.Sequential(
            nn.Linear(low_feature_dim, high_feature_dim),
        )
        
        self.Common_view = nn.Sequential(
            nn.Linear(low_feature_dim*view, high_feature_dim),
        )        

        self.view = view
        self.TransformerEncoderLayer = nn.TransformerEncoderLayer(d_model=low_feature_dim*view, nhead=1, dim_feedforward=256)
        # self.TransformerEncoder = nn.TransformerEncoder(self.TransformerEncoderLayer, num_layers=1)
        
        
        self.label_contrastive_module = nn.Sequential(
            nn.Linear(low_feature_dim, class_num),
            nn.Softmax(dim=1)
        )
        
        self.label_contrastive_module1 = nn.Sequential(
            nn.Linear(low_feature_dim*view,class_num),
            nn.Softmax(dim=1)
        )
            
    def forward(self, xs):
        xrs = []
        zs = []
        hs = []
        # zzs = []
        qs = []
        for v in range(self.view):          
            x = xs[v]
            z = self.encoders[v](x)
            h = normalize(self.Specific_view(z), dim=1)
            q = self.label_contrastive_module(z)
            xr = self.decoders[v](z)
            hs.append(h)
            qs.append(q)
            zs.append(z)
            # zzs.append(zs)
            xrs.append(xr)
        return  xrs, zs, hs,qs

    
    def GCFAgg(self, xs):
        zs = []
        for v in range(self.view):
            x = xs[v]
            z = self.encoders[v](x)
            zs.append(z)
        # print(zs.size())
        
        commonz = torch.cat(zs, dim=1)
        commonz, S = self.TransformerEncoderLayer(commonz)
        
        commonz1 = normalize(self.Common_view(commonz), dim=1)
        commonq = self.label_contrastive_module1(commonz)

        return commonz1, S,commonq



    # def get_loss(self, xs, y=None):
    #     # hs = self._get_hs(Xs)
    #     # z = self.fusion_layer(hs)
    #     hs = []
    #     for v in range(self.view):          
    #         x = xs[v]
    #         z = self.encoders[v](x)
    #         h = normalize(self.Specific_view(z), dim=1)
    #         hs.append(h)
        
    #     z,_ = self.GCFAgg(xs)
        
    #     if y is not None and self.classification:
    #         z = self.classifier(z)
    #         loss = self.supervised_loss(z, y)
    #         return loss
    #     else:
    #         if self.args.contrastive.ins_enable:
    #             loss_ins = self.instance_loss.get_loss(z, hs)
    #         else:
    #             loss_ins = 0
    #         if self.args.contrastive.cls_enable:
    #             loss_cls = self.cls_loss.get_loss(z, hs)
    #         else:
    #             loss_cls = 0
            
    #         total_loss = self.args.contrastive.ins_lambda * loss_ins + self.args.contrastive.cls_lambda * loss_cls
            
    #         return total_loss, (loss_ins, loss_cls)
    
    def Cluster_en(self,xs):
        zs = []
        for v in range(self.view):
            x = xs[v]
            z = self.encoders[v](x)
            z = z.unsqueeze(1)
            zs.append(z)
        # print(zs.size())
        
        commonz = torch.cat(zs, dim=2)
        commonz, _ = self.TransformerEncoderLayer(commonz)
        commonz = commonz.transpose(0, 1)
        # mean pooling
        commonz = commonz.mean(dim=0)
        commonz = normalize(self.Common_view(commonz), dim=1)
        return commonz
    
    # def get_loss(self, Xs, labels=None):
    #     if labels is not None:
    #         y = self(Xs)
    #         cls_loss = self.cls_criterion(y, labels)
    #         return cls_loss
        
    # def get_cls_optimizer(self):
    #     self.cls_optimizer = torch.optim.SGD(chain(self.encoders.parameters(),
    #                                                self.TransformerEncoder.parameters(), 
    #                                                self.cls_layer.parameters()),
    #                                          lr=1e-3,
    #                                          momentum=0.9,
    #                                          weight_decay=5e-4)
    #     return self.cls_optimizer
